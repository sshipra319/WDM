<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="CSS/leanevent.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<title>Recover Password</title>
</head>
<body>
	<header>
		<div class="recoverpwd">
		<p style="font-family: Roboto; font-size: 0.70em; color: #595959;margin-left:6px;">Recuperar su Contrasena </p> 
		<hr style="color: #FFFFFF;">
		<label style="color: #595959; font-size: 0.70em; font-family: Roboto;margin-left:6px;"> Correo</label><br/>
<input type="text"id="correo"name="country"placeholder="Correo"style="color:#595959;font-size:0.70em;font-family:Roboto;height:40px;margin-left:6px; width: 460px;">
<br/><br/>
<hr style="color: #FFFFFF;">
<input type="submitCerrar" name="cerrar" value="Cerrar">
<input type="submitEnviar" name="enviar" value="Enviar"><br/>
</div>
	</header>


</body>
</html>