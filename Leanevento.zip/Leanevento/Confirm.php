<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="CSS/leanevent.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<title>Confirmation</title>
</head>
<body>
	<header>
		<div class="confirm">
		<h3 style="font-family: Roboto; text-align: center; color: #595959; font-size: larger;">Bienvenido </h3> 
		<hr style="color: #FFFFFF;">
		<p style="font-family: Roboto; color: #595959; text-align: center;"> Gracias por ser un Voluntario en nuestros evento. </p>
<hr style="color: #FFFFFF;">
<input type="submitClose" name="close" value="Close"><br/>
</div>
	</header>


</body>
</html>